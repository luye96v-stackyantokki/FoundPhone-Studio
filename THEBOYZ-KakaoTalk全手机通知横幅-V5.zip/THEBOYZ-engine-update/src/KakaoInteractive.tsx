import { useEffect, useState } from "react";
import type { Work } from "./schema";
import "./kakao-interactive.css";

type Message = { id: number; mine: boolean; ko: string; zh: string; time: string };
type Route = { affection: number; flirting: number; messages: Message[]; lastDaily?: number; pendingDaily?: number };
type Save = { selected: string; routes: Record<string, Route> };
type Scene = { opening: string[]; choices: string[][] };
const shortcuts = [
  { label: "在干嘛", ko: "뭐 해?", replies: [["방금 연습 끝났어ㅎㅎ", "刚结束练习ㅎㅎ"], ["너 생각하고 있었지ㅋㅋ", "正在想你啊ㅋㅋ"], ["잠깐 쉬고 있어. 너는?", "正在休息一会儿。你呢？"]] },
  { label: "抱抱", ko: "안아 줘", replies: [["이리 와ㅎㅎ", "过来ㅎㅎ"], ["갑자기? ㅋㅋ 귀엽네", "突然？ㅋㅋ好可爱"], ["지금 옆에 있었으면 안아 줬을 텐데.", "如果现在在你身边就能抱抱你了。"]] },
  { label: "想你了", ko: "보고 싶어", replies: [["나도 보고 싶어ㅎㅎ", "我也想你ㅎㅎ"], ["얼마나? ㅋㅋ", "有多想？ㅋㅋ"], ["그런 말 하면 나도 보고 싶어지잖아.", "你这么说，我也会想见你啊。"]] },
  { label: "夸夸我", ko: "나 칭찬해 줘", replies: [["오늘도 수고했어. 잘했어ㅎㅎ", "今天也辛苦啦，做得很好ㅎㅎ"], ["우리 애기 잘했네ㅋㅋ", "我们宝宝真棒ㅋㅋ"], ["너는 생각보다 훨씬 멋진 사람이야.", "你比自己想的还要厉害。"]] },
  { label: "哄我", ko: "나 좀 달래 줘", replies: [["무슨 일 있어? 내가 들어 줄게.", "怎么啦？我听你说。"], ["속상했어? 이리 와ㅠㅠ", "受委屈了吗？过来ㅠㅠ"], ["오늘은 내가 네 편 할게ㅎㅎ", "今天我站在你这边ㅎㅎ"]] },
  { label: "要打电话吗", ko: "전화할까?", replies: [["좋지ㅎㅎ 조금 있다가 할까?", "好呀ㅎㅎ等一会儿打？"], ["지금 네 목소리 듣고 싶긴 해ㅋㅋ", "现在确实有点想听你的声音ㅋㅋ"], ["오늘은 일정이 있어서ㅠㅠ 끝나고 연락할게.", "今天有行程ㅠㅠ结束后联系你。"]] },
];
export const dailyScenes: Scene[] = [
 {opening:["오늘 뭐 했어? ㅎㅎ","今天做什么了？ㅎㅎ"],choices:[["오빠 생각했지","想哥哥了呀","그럼 나도 네 생각 더 해야겠다ㅋㅋ","那我也得多想想你了ㅋㅋ"],["그냥 평범한 하루였어","普通的一天","그런 날도 좋지. 나랑 얘기하자ㅎㅎ","那样也挺好。和我聊聊天吧ㅎㅎ"],["비밀이야ㅋㅋ","秘密ㅋㅋ","나한테도 비밀이야? 너무하네ㅋㅋ","连我也不能说？太过分了ㅋㅋ"]]},
 {opening:["갑자기 네 목소리 듣고 싶네","突然有点想听你的声音"],choices:[["전화할까?","要打电话吗？","진짜? 나 괜히 설레잖아ㅋㅋ","真的？害我莫名有点心动ㅋㅋ"],["왜? 보고 싶어?","为什么？想我了？","응. 조금 많이ㅎㅎ","嗯，有点太想了ㅎㅎ"],["다음에 들려줄게","下次再让你听","약속한 거다?ㅎㅎ","说好了哦？ㅎㅎ"]]},
 {opening:["너 오늘 왜 이렇게 귀여워?ㅋㅋ","你今天怎么这么可爱？ㅋㅋ"],choices:[["오빠한테만 그래","只对哥哥这样","그런 말 자꾸 하면 나 기대한다?","总这样说我可会期待的哦？"],["원래 귀엽거든","我本来就可爱","맞아ㅋㅋ 인정할게","是是ㅋㅋ我承认"],["나 못 봤잖아ㅋㅋ","你又没看到我ㅋㅋ","안 봐도 알 것 같은데ㅎㅎ","没看到也能猜到ㅎㅎ"]]},
 {opening:["아까 노래 듣다가 네 생각났어","刚刚听歌的时候想到你了"],choices:[["무슨 노래?","什么歌？","다음에 같이 듣자ㅎㅎ","下次一起听ㅎㅎ"],["나도 오빠 생각했어","我也想到哥哥了","우리 통했네ㅋㅋ","我们心有灵犀呢ㅋㅋ"],["왜 내 생각이 나?","为什么想到我？","그건 비밀ㅎㅎ","那是秘密ㅎㅎ"]]},
 {opening:["밥은 먹었어?","吃饭了吗？"],choices:[["아직, 오빠는?","还没，哥哥呢？","나도 아직. 꼭 챙겨 먹어ㅎㅎ","我也还没。一定要好好吃饭ㅎㅎ"],["먹었지ㅎㅎ","吃过啦ㅎㅎ","잘했어. 뭐 먹었어?","真乖。吃了什么？"],["오빠가 사 줘ㅋㅋ","哥哥请我吃ㅋㅋ","좋아ㅋㅋ 뭐 먹고 싶은데?","好啊ㅋㅋ想吃什么？"]]},
 {opening:["오늘따라 시간이 안 가네ㅠㅠ","今天感觉时间过得好慢ㅠㅠ"],choices:[["나랑 얘기하면 빨리 가","跟我聊天就快啦","그럼 계속 얘기해 줘ㅎㅎ","那就继续陪我聊ㅎㅎ"],["많이 바빠?","很忙吗？","조금. 그래도 잠깐 쉴 수 있어","有点。不过能休息一会儿"],["보고 싶어서 그래?ㅋㅋ","是因为想我了吗？ㅋㅋ","들켰나?ㅋㅋ","被发现了吗？ㅋㅋ"]]},
 {opening:["너 지금 웃고 있어?","你现在在笑吗？"],choices:[["응, 오빠 때문에ㅎㅎ","嗯，因为哥哥ㅎㅎ","아 진짜? 나도 웃게 되네","啊真的？害我也笑了"],["왜 궁금해?","为什么好奇？","그냥 네 표정이 궁금해서","就是好奇你的表情"],["아니, 웃겨 줘","没有，逗我笑呀","ㅋㅋㅋ 갑자기 숙제 생겼네","ㅋㅋㅋ突然给我布置任务了"]]},
 {opening:["잠깐 쉬는 중이야. 너는?","我正在休息一会儿。你呢？"],choices:[["오빠 기다리는 중","在等哥哥","그럼 잘 찾아왔네ㅎㅎ","那我来得正好ㅎㅎ"],["나도 쉬고 있어","我也在休息","좋다. 같이 쉬자","真好。一起休息吧"],["비밀ㅋㅋ","保密ㅋㅋ","왜 자꾸 궁금하게 해ㅋㅋ","干嘛总让我好奇ㅋㅋ"]]},
 {opening:["내일도 연락해도 돼?","明天也可以联系你吗？"],choices:[["매일 해도 돼","每天都可以","그 말 기억할게ㅎㅎ","我会记住这句话ㅎㅎ"],["내가 먼저 할 건데?","我会先联系哥哥的呀？","그럼 기다릴게ㅋㅋ","那我等着ㅋㅋ"],["왜 허락을 받아ㅋㅋ","干嘛还要征求同意ㅋㅋ","혹시 방해될까 봐ㅎㅎ","怕打扰你嘛ㅎㅎ"]]},
 {opening:["나 지금 괜히 기분 좋아ㅎㅎ","我现在莫名心情很好ㅎㅎ"],choices:[["나 때문이지?","是因为我吧？","어떻게 알았어ㅋㅋ","你怎么知道ㅋㅋ"],["무슨 좋은 일 있어?","有什么好事吗？","너랑 얘기하고 있잖아ㅎㅎ","不是正在和你聊天嘛ㅎㅎ"],["나도 기분 좋아","我心情也很好","그럼 오늘 둘 다 좋은 날이네","那今天对我们俩都是好日子"]]}
];
export const storageKey = (id: string) => `theboyz:kkt:v1:${id}`;
export function load(id: string): Save {
  try { const value = JSON.parse(localStorage.getItem(storageKey(id)) || "null"); if (value && typeof value.routes === "object") return value; } catch { /* unavailable storage */ }
  return { selected: "", routes: {} };
}
export function KakaoInteractive({ work, onBack }: { work: Work; onBack: () => void }) {
  const contacts = (work.data.contacts ?? []).filter(c => ["hyunjae", "juyeon", "younghoon", "sunwoo", "q", "eric", "juhaknyeon", "kevin", "new", "sangyeon"].includes(c.id.replace(/-card$/, ""))).map(c => ({ id: c.id.replace(/-card$/, ""), name: c.title }));
  const [save, setSave] = useState<Save>(() => load(work.id));
  const [pending, setPending] = useState<{ kind: "quick" | "daily"; index: number } | null>(() => { const saved = load(work.id); const idx = saved.routes[saved.selected]?.pendingDaily; return typeof idx === "number" ? { kind: "daily", index: idx } : null; });
  const [expanded, setExpanded] = useState(false);
  const [notice, setNotice] = useState("");
  useEffect(() => { try { localStorage.setItem(storageKey(work.id), JSON.stringify(save)); } catch { setNotice("浏览器禁止本地存储，聊天可能无法保存。"); } }, [save, work.id]);
  const route = save.routes[save.selected] ?? { affection: 30, flirting: 20, messages: [] };
  const active = contacts.find(c => c.id === save.selected);
  const activePending = active ? save.routes[active.id]?.pendingDaily : undefined;
  useEffect(() => {
    if (typeof activePending === "number" && pending === null) setPending({ kind: "daily", index: activePending });
  }, [active?.id, activePending]);
  useEffect(() => {
    const sync = () => { setSave(load(work.id)); setPending(null); setExpanded(false); };
    window.addEventListener("theboyz:kkt-update", sync);
    return () => window.removeEventListener("theboyz:kkt-update", sync);
  }, [work.id]);
  const stamp = () => new Date().toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit", hour12: false });
  const append = (personId: string, additions: Message[], affection = 0, flirting = 0) => {
    setSave(s => { const old = s.routes[personId] ?? { affection: 30, flirting: 20, messages: [] }; return { ...s, routes: { ...s.routes, [personId]: { ...old, messages: [...old.messages, ...additions], affection: Math.min(100, old.affection + affection), flirting: Math.min(100, old.flirting + flirting) } } }; });
  };
  const choiceSets: Scene[] = [
    { opening: ["뭐 하고 있어? 갑자기 네 생각나서ㅎㅎ", "在干嘛？突然想到你了ㅎㅎ"], choices: [
      ["나도 오빠 생각 중이었어", "我也在想哥哥", "진짜? ㅋㅋ 우리 통했네.", "真的？ㅋㅋ我们心有灵犀呢。"],
      ["나 기다렸어?", "哥哥在等我吗？", "응, 조금ㅎㅎ 먼저 연락할까 고민했어.", "嗯，有一点ㅎㅎ刚刚还在犹豫要不要先联系你。"],
      ["친구 만나고 있었어", "刚刚在见朋友", "아 그렇구나ㅎㅎ 재밌게 놀았어?", "这样呀ㅎㅎ玩得开心吗？"] ] },
    { opening: ["지금 옆에 있으면 안아 줬을 텐데.", "如果现在在你身边，就能抱抱你了。"], choices: [
      ["그럼 지금 와 줘", "那哥哥现在过来", "ㅋㅋㅋ 그렇게 말하면 진짜 가고 싶잖아.", "ㅋㅋㅋ你这么说，我真的会想过去啊。"],
      ["꼭 안아 줘야 해", "要抱紧一点哦", "알겠어ㅎㅎ 쉽게 안 놔줄게.", "知道啦ㅎㅎ不会轻易松开的。"],
      ["말로만? ㅋㅋ", "只会嘴上说说？ㅋㅋ", "아니거든ㅋㅋ 다음에 만나면 확인해 봐.", "才不是ㅋㅋ下次见面你可以确认一下。"] ] },
    { opening: ["나도 보고 싶어. 얼마나 보고 싶어? ㅋㅋ", "我也想你。有多想我？ㅋㅋ"], choices: [
      ["엄청 많이", "超级超级想", "아 어떡해ㅋㅋ 나도 더 보고 싶어졌어.", "啊怎么办ㅋㅋ我更想见你了。"],
      ["오빠가 더 보고 싶어 해야지", "应该哥哥更想我才对", "그럼 내가 더 많이 보고 싶어할게ㅎㅎ", "那就让我更想你一点吧ㅎㅎ"],
      ["비밀이야", "保密", "치사해ㅋㅋ 나한테만 알려 줘.", "好过分ㅋㅋ只告诉我嘛。"] ] },
    { opening: ["오늘도 수고했어. 근데 왜 칭찬받고 싶어? ㅎㅎ", "今天也辛苦啦。不过怎么突然想被夸？ㅎㅎ"], choices: [
      ["오늘 진짜 열심히 했거든", "因为我今天真的很努力", "잘했어ㅎㅎ 정말 자랑스럽다.", "做得好ㅎㅎ真的为你骄傲。"],
      ["오빠한테 듣고 싶어서", "因为想听哥哥夸我", "그럼 매일 해 줄까? ㅋㅋ", "那要不要我每天都夸你？ㅋㅋ"],
      ["그냥 애교 부리는 거야", "就是想撒娇嘛", "알아ㅋㅋ 귀여워서 큰일이네.", "知道啦ㅋㅋ可爱得让人没办法。"] ] },
    { opening: ["무슨 일 있어? 내가 들어 줄게.", "怎么啦？我听你说。"], choices: [
      ["그냥 오빠가 보고 싶어", "只是想哥哥了", "그런 거였어? ㅎㅎ 나 여기 있잖아.", "原来是这样？ㅎㅎ我不是在这里嘛。"],
      ["오늘 좀 속상했어", "今天有点难过", "그랬구나ㅠㅠ 천천히 말해 줘. 내가 들을게.", "这样啊ㅠㅠ慢慢说，我听着呢。"],
      ["귀엽다고 해 줘", "说我可爱嘛", "우리 귀염둥이ㅎㅎ 이제 좀 괜찮아?", "我们的小可爱ㅎㅎ现在好一点了吗？"] ] },
    { opening: ["전화? ㅎㅎ 지금 네 목소리 듣고 싶긴 해.", "打电话？ㅎㅎ现在确实有点想听你的声音。"], choices: [
      ["그럼 지금 전화해", "那现在打给我", "ㅋㅋㅋ 잠깐만, 이어폰 찾을게.", "ㅋㅋㅋ等一下，我找找耳机。"],
      ["목소리 듣고 싶었어?", "哥哥想听我的声音吗？", "응. 생각보다 많이ㅎㅎ", "嗯，比想象中还想ㅎㅎ"],
      ["다음에 하자", "下次再打吧", "좋아ㅎㅎ 그때는 내가 먼저 연락할게.", "好呀ㅎㅎ到时候我先联系你。"] ] },
  ];
  const trigger = (idx: number) => {
    if (!active) return;
    const item = shortcuts[idx]; const scene = choiceSets[idx]; const id = Date.now(); const time = stamp();
    append(active.id, [{ id, mine: true, ko: item.ko, zh: item.label, time }, { id: id + 1, mine: false, ko: scene.opening[0], zh: scene.opening[1], time }]);
    setPending({ kind: "quick", index: idx }); setExpanded(false);
  };
  const choose = (idx: number) => {
    if (!active || pending === null) return;
    const choice = (pending.kind === "daily" ? dailyScenes : choiceSets)[pending.index].choices[idx]; const id = Date.now(); const time = stamp();
    append(active.id, [{ id, mine: true, ko: choice[0], zh: choice[1], time }, { id: id + 1, mine: false, ko: choice[2], zh: choice[3], time }], idx === 0 ? 2 : 1, idx === 1 ? 2 : 1);
    setSave(s => ({...s, routes: {...s.routes, [active.id]: {...s.routes[active.id], pendingDaily: undefined}}}));
    setPending(null); setExpanded(false);
  };
  return <div className="kkt-root">
    <header className="kkt-header"><button onClick={active ? () => { setSave(s => ({ ...s, selected: "" })); setPending(null); setExpanded(false); } : onBack}>‹ 返回</button><strong>{active ? active.name : "KakaoTalk"}</strong><span>💬</span></header>
    {!active ? <><div className="kkt-intro">选择聊天对象 · 每位男主独立保存聊天和数值</div><div className="kkt-contacts">{contacts.map(c => { const r = save.routes[c.id]; return <button key={c.id} className="kkt-contact" onClick={() => { setSave(s => ({ ...s, selected: c.id })); const idx = save.routes[c.id]?.pendingDaily; setPending(typeof idx === "number" ? { kind: "daily", index: idx } : null); setExpanded(false); }}><span className="kkt-avatar">{c.name.slice(0,1)}</span><span><b>{c.name}</b><small>{r?.messages.at(-1)?.zh ?? "点击开始聊天"}</small></span><span>›</span></button>; })}</div></> : <>
      <div className="kkt-stats">♡ 好感度 {route.affection}　·　💕 暧昧值 {route.flirting}</div>
      <div className="kkt-messages" key={active.id}><div className="kkt-day">今天</div>{route.messages.length === 0 && <div className="kkt-hint">可以使用快捷话题，也可以等待对方主动发消息 ♡</div>}{route.messages.map(m => <div key={m.id} className={`kkt-message ${m.mine ? "mine" : "theirs"}`}>{!m.mine && <span className="kkt-avatar mini">{active.name.slice(0,1)}</span>}<div className="kkt-bubble"><span>{m.ko}</span><small>{m.zh}</small></div><time>{m.time}</time></div>)}</div>
      <div className="kkt-bottom">
        {pending !== null && expanded && <div className="kkt-options">{(pending.kind === "daily" ? dailyScenes : choiceSets)[pending.index].choices.map((c,i) => <button key={i} onClick={() => choose(i)}><span>{c[0]}</span><small>{c[1]}</small></button>)}<button className="kkt-collapse" onClick={() => setExpanded(false)}>收起⌄</button></div>}
        <div className="kkt-inputrow"><button className="kkt-input" onClick={() => { if (pending !== null) setExpanded(v => !v); else setExpanded(false); }}>{pending !== null ? "点击选择回复…" : "选择下方话题开始聊天…"}</button><button className="kkt-send" disabled={pending === null} onClick={() => setExpanded(v => !v)}>选项</button></div>
        {pending === null && <div className="kkt-quick">{shortcuts.map((s,i) => <button key={s.label} onClick={() => trigger(i)}>{s.label}</button>)}</div>}
      </div>
    </>}{notice && <div className="kkt-notice">{notice}</div>}
  </div>;
}
